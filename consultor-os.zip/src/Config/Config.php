<?php
namespace App\Config;

class Config {
    // URL Base do projeto (ajuste se estiver em subpasta)
    const BASE_URL = 'https://bpso.com.br/projetos/consultor-os/public';

    // Credenciais do Banco
    const DB_HOST = '193.203.175.53';
    const DB_NAME = 'u779956625_consultorOs'; // Nome exato que vi no seu print
    const DB_USER = 'u779956625_user_admin8';        // Seu usuário local
    const DB_PASS = 'Adminbpso281*';            // Sua senha local
}