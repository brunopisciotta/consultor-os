<?php
// Este arquivo serve apenas para redirecionar quem acessa a raiz
// para a pasta pública onde o sistema roda de verdade.
header('Location: public/');
exit;